#pragma once
class cRingBuffer
{
	cRingBuffer();
	~cRingBuffer();
};