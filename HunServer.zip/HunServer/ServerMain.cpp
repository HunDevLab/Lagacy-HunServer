// HunServer.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"


int main()
{
	cIocpManager* server = new cIocpManager;
	server->Begin();

	while (true);
	/*flatbuffers::FlatBufferBuilder builder(1024);
	auto weapon_one_name = builder.CreateString("sword");
	short weapon_one_damage = 3;

	auto weapon_two_name = builder.CreateString("Axe");
	short weapon_two_damage = 5;

	auto sword = MyGame::Sample::CreateWeapon(builder, weapon_one_name, weapon_one_damage);
	std::vector<flatbuffers::Offset<MyGame::Sample::Weapon>> weapons_vector;
	weapons_vector.push_back(sword);
	builder.Finish(sword);*/
}

