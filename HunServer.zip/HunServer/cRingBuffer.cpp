#include "stdafx.h"
#include "cRingBuffer.h"

cRingBuffer::cRingBuffer()
{

}
cRingBuffer::~cRingBuffer()
{

}